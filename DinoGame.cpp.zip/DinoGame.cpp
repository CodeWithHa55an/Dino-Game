

#include "raylib.h"
#include <cmath>
#include <vector>

struct RainDrop
{
    float x;
    float y;
    float speed;
};

struct SnowFlake
{
    float x;
    float y;
    float speed;
    float size;
    float driftPhase;
};

int GetNextBirdScore(int score) {
    int base = (score / 300) * 300;
    int phase = score % 300;

    // Single Targets (1-100)
    if (phase < 15) return base + 15;
    if (phase < 30) return base + 30;
    if (phase < 45) return base + 45;
    if (phase < 60) return base + 60;
    if (phase < 75) return base + 75;
    if (phase < 95) return base + 95;

    // Double Targets (101-200)
    if (phase < 110) return base + 110;
    if (phase < 125) return base + 125;
    if (phase < 140) return base + 140;
    if (phase < 155) return base + 155;
    if (phase < 170) return base + 170;
    if (phase < 185) return base + 185;
    if (phase < 200) return base + 200;

    // Alternating Targets (201-300)
    for (int i = 210; i <= 300; i += 10) {
        if (phase < i) return base + i;
    }

    return base + 300 + 15;
}

bool IsDoubleBirdScore(int spawnScore) {
    int phase = spawnScore % 300;
    if (phase == 0) phase = 300;

    if (phase <= 100) return false;
    if (phase <= 200) return true;

    // 201-300 alternating: 210 (single), 220 (double)
    return (phase % 20 == 0);
}
int main()
{
    const int screenWidth = 800;
    const int screenHeight = 420;
    // ==================== SETUP ====================
    // ==================== SETUP ====================
    InitWindow(screenWidth, screenHeight, "Dino Game");
    InitAudioDevice();
    SetTargetFPS(60);

    // ==================== AUDIO LOADING ====================
    Sound jumpSfx = LoadSound("Assets/JumpSfx.mp3");
    Sound landingSfx = LoadSound("Assets/Landing.mp3");
    Sound gameOverSfx = LoadSound("Assets/GameOver.mp3");
    Sound thunderSfx = LoadSound("Assets/Thunder.mp3");
    Sound buttonSfx = LoadSound("Assets/Button.mp3");

    Music gameMenuMusic = LoadMusicStream("Assets/GameMenu.mp3");
    Music gameBgMusic = LoadMusicStream("Assets/GameBgSfx.mp3");
    Music rainMusic = LoadMusicStream("Assets/Rain1.mp3");
    Music snowMusic = LoadMusicStream("Assets/Snowfall.mp3");

    // Start menu music
    PlayMusicStream(gameMenuMusic);

    // Load textures from the correct Assets folder
    Texture2D birdUpTexture = LoadTexture("Assets/Bird.png");
    Texture2D birdLevel2Texture = LoadTexture("Assets/Bird_Level2.png");
    Texture2D birdDown2Texture = LoadTexture("Assets/Bird_Down2.png");
    // Summer cactuses
    Texture2D cactusTexture = LoadTexture("Assets/Cactus.png");
    Texture2D cactusShortTexture = LoadTexture("Assets/Cactus_Short.png");
    Texture2D cactusTallTexture = LoadTexture("Assets/Cactus_Tall.png");
    Texture2D cactusVeryTallTexture = LoadTexture("Assets/Cactus_VeryTall.png");
    // dino
    Texture2D dinoIdleTexture = LoadTexture("Assets/Dino1.png");
    Texture2D dinoRun1Texture = LoadTexture("Assets/DinoFrontleg1.png");
    Texture2D dinoRun2Texture = LoadTexture("Assets/DinoBackleg1.png");
    Texture2D dinoJump = LoadTexture("Assets/Dinojump1.png");
    Texture2D dinoCrouchTexture = LoadTexture("Assets/DinoCrouch1.png");
    // Summer
    Texture2D desertBG = LoadTexture("Assets/Summer/DesertBG1 copy.png");
    Texture2D bigCloud = LoadTexture("Assets/Summer/BigCloud.png");
    Texture2D smallCloud = LoadTexture("Assets/Summer/SmallCloud.png");
    Texture2D bigMountain = LoadTexture("Assets/Summer/BigDesertMountain.png");
    Texture2D smallMountain = LoadTexture("Assets/Summer/SmallDesertMountain.png");
    Texture2D sunTexture = LoadTexture("Assets/Summer/Sun.png");
    Texture2D moonSummer = LoadTexture("Assets/Summer/Moon.png");
    Texture2D soilGround = LoadTexture("Assets/Summer/SoilGround.png");
    Texture2D heatWave = LoadTexture("Assets/Summer/HeatWave.png");
    Texture2D rainycloud = LoadTexture("Assets/Summer/RainyCloud.png");
    // Winter
    Texture2D snowBG = LoadTexture("Assets/Winter/SnowBackground.png");
    Texture2D winterCloud = LoadTexture("Assets/Winter/Cloud.png");
    Texture2D fogTexture = LoadTexture("Assets/Winter/Fog.png");
    Texture2D snowGround = LoadTexture("Assets/Winter/SnowGround.png");
    Texture2D moonWinter = LoadTexture("Assets/Winter/Moon.png");
    // Winter Cactus
    Texture2D cactusSnowTexture = LoadTexture("Assets/Winter/CactusSnowy.png");
    Texture2D cactusShortSnowTexture = LoadTexture("Assets/Winter/CactusShortSnow.png");
    Texture2D cactusTallSnowTexture = LoadTexture("Assets/Winter/CactusTallSnowy.png");
    Texture2D cactusVeryTallSnowTexture = LoadTexture("Assets/Winter/CactusVeryTallSnowy.png");
    Texture2D cactusFrostedTexture = LoadTexture("Assets/Winter/CactusFrosted.png");
    // Menu
    Texture2D menu = LoadTexture("Assets/Menu.png");
    // Tutorial
    Texture2D tutorial = LoadTexture("Assets/Tutorial.png");

    // ==================== DINO VARIABLES ====================
    int dinoX = 100;
    int dinoY = 230;
    int dinoWidth = 62;
    int dinoHeight = 80;

    int dinoSpeed = 0;
    int gravity = 1;
    int jumpPower = 18;
    int ground = 280;
    bool isJumping = false;
    bool isMoving = false;
    int dinoRunCounter = 0;
    int dinoRunFrame = 0;

    // ==================== CACTUS VARIABLES ====================
    int cactusX = 800 + GetRandomValue(0, 300);
    int cactusY = 360 - 50;
    int cactusWidth = 30;
    int cactusHeight = 50;
    int cactusType = 0;
    int cactusSpeed = 5;

    int cactus2X = 1400;
    int cactus2Y = 360 - 50;
    int cactus2Width = 30;
    int cactus2Height = 50;
    int cactus2Type = 0;
    bool secondCactusActive = false;

    auto SetCactusSize = [&](int type, int &width, int &height)
    {
        if (type == 1)
        {
            width = 30;
            height = 35;
        }
        else if (type == 2)
        {
            width = 30;
            height = 80;
        }
        else if (type == 3)
        {
            width = 30;
            height = 65;
        }
        else
        {
            width = 30;
            height = 50;
        }
    };
    const int rainCloudCount = 18;

    float rainCloudX[rainCloudCount];
    float rainCloudY[rainCloudCount];
    // ==================== CLOUD VARIABLES ====================
    int cloud1X = 800;
    int cloud1Y = 80;
    int cloud2X = 1100;
    int cloud2Y = 120;
    int cloud3X = 1400;
    int cloud3Y = 60;

    // ==================== MOUNTAINS ====================
    float bigMountainX = 0;
    float smallMountainX = 450;

    float mountainSpeed = 1.0f;

    // ==================== BIRD VARIABLES ====================
    int birdX = 800;
    int birdY = 200;
    int birdWidth = 40;
    int birdHeight = 15;
    int birdSpeed = 7;
    bool birdActive = false;
    int birdAnimationCounter = 0;
    int birdAnimationType = 0; // 0=up, 1=level, 2=down
    bool isDoubleBird = false;

    // ==================== GAME VARIABLES ====================
    bool gameStarted = false;
    bool gameOver = false;
    int score = 0;
    int highscore = 0;
    int nextBirdSpawnScore = 15;
    bool birdSpawnedAtThisScore = false;

    // Lightning
    float lightningFlashAlpha = 0.0f;
    struct LightningSegment {
        Vector2 start;
        Vector2 end;
    };
    std::vector<LightningSegment> lightningPath;
    // Rain
    const int rainCount = 80;
    RainDrop rain[rainCount];

    // Snow
    const int snowCount = 100;
    SnowFlake snow[snowCount];

    // ==================== DAY / NIGHT ====================
    bool isNight = false;
    int nextDayNightScore = 5; // Change every 20 points

    int selectedEnvironment = 0;
    // 0 = not selected
    // 1 = Summer
    // 2 = Winter

    int summerPhase = 0;
    // 0 = Day (0–20)
    // 1 = Night (20–40)
    // 2 = Cloudy (40–60)
    // 3 = Sunny Heat (60–80)
    bool isCrouching = false;
    float cloudAlpha = 0.0f;

    bool cloudEntering = false;
    bool cloudLeaving = false;
    float leftCloudOffset = -500.0f;
    float rightCloudOffset = 800.0f;
    float cloudFade = 0.0f;

    bool showTutorial = false;

    auto ChooseCactusType = [&](int score)
    {
        if (selectedEnvironment == 1)
        {
            if (score < 20)
                return GetRandomValue(0, 1);
            else if (score < 30)
                return GetRandomValue(0, 2);
            else
                return GetRandomValue(0, 3);
        }
        else
        {
            if (score < 20)
                return GetRandomValue(0, 2);
            else
                return GetRandomValue(0, 4);
        }
    };

    auto GetCactusTextureForType = [&](int type, bool winter)
    {
        if (winter)
        {
            if (type == 1)
                return cactusShortSnowTexture;
            if (type == 2)
                return cactusVeryTallSnowTexture;
            if (type == 3)
                return cactusTallSnowTexture;
            if (type == 4)
                return cactusFrostedTexture;
            return cactusSnowTexture;
        }

        if (type == 1)
            return cactusShortTexture;
        if (type == 2)
            return cactusVeryTallTexture;
        if (type == 3)
            return cactusTallTexture;
        return cactusTexture;
    };
    for (int i = 0; i < rainCloudCount; i++)
    {
        rainCloudX[i] = (i % 6) * 140 - 30;
        rainCloudY[i] = 20 + (i / 6) * 45;
    }
    for (int i = 0; i < rainCount; i++)
    {
        rain[i].x = GetRandomValue(0, screenWidth);
        rain[i].y = GetRandomValue(110, screenHeight);

        // All drops have similar speed (more realistic)
        rain[i].speed = GetRandomValue(12, 18);
    }

    for (int i = 0; i < snowCount; i++)
    {
        snow[i].x = GetRandomValue(0, screenWidth);
        snow[i].y = GetRandomValue(0, screenHeight);
        snow[i].speed = GetRandomValue(2, 5) * 0.5f;
        snow[i].size = GetRandomValue(1, 3);
        snow[i].driftPhase = GetRandomValue(0, 100) / 10.0f;
    }
    float sunX = 750;
    float moonX = 850;
    float sunY = 30;
    float moonY = 50;
    float sunMoveProgress = 0.0f;
    float moonMoveProgress = 0.0f;
    int lastCyclePhase = 0;

    auto LerpColor = [](Color a, Color b, float t) -> Color
    {
        t = (t < 0.0f) ? 0.0f : ((t > 1.0f) ? 1.0f : t);
        return (Color){
            (unsigned char)(a.r + (b.r - a.r) * t),
            (unsigned char)(a.g + (b.g - a.g) * t),
            (unsigned char)(a.b + (b.b - a.b) * t),
            (unsigned char)(a.a + (b.a - a.a) * t)};
    };

    int lastWeatherPhase = 0;
    bool weatherTransitionActive = false;
    float weatherTransitionProgress = 1.0f;
    int weatherTransitionFromPhase = 0;
    int weatherTransitionToPhase = 0;
    float weatherTransitionDuration = 1.2f;
    
    float shakeDuration = 0.0f;
    Camera2D camera = { 0 };
    camera.zoom = 1.0f;

    // ==================== GAME LOOP ====================
    while (!WindowShouldClose())
    {
        // Update audio streams
        UpdateMusicStream(gameMenuMusic);
        UpdateMusicStream(gameBgMusic);
        UpdateMusicStream(rainMusic);
        UpdateMusicStream(snowMusic);

        if (!gameStarted) {
            if (!IsMusicStreamPlaying(gameMenuMusic)) PlayMusicStream(gameMenuMusic);
            if (IsMusicStreamPlaying(gameBgMusic)) StopMusicStream(gameBgMusic);
            if (IsMusicStreamPlaying(rainMusic)) StopMusicStream(rainMusic);
            if (IsMusicStreamPlaying(snowMusic)) StopMusicStream(snowMusic);
        } else {
            if (IsMusicStreamPlaying(gameMenuMusic)) StopMusicStream(gameMenuMusic);
            if (!IsMusicStreamPlaying(gameBgMusic)) PlayMusicStream(gameBgMusic);

            bool isRaining = (selectedEnvironment == 1 && (summerPhase == 3 || summerPhase == 4));
            bool isSnowing = (selectedEnvironment == 2);

            if (isRaining && !gameOver) {
                if (!IsMusicStreamPlaying(rainMusic)) PlayMusicStream(rainMusic);
            } else {
                if (IsMusicStreamPlaying(rainMusic)) StopMusicStream(rainMusic);
            }

            if (isSnowing && !gameOver) {
                if (!IsMusicStreamPlaying(snowMusic)) PlayMusicStream(snowMusic);
            } else {
                if (IsMusicStreamPlaying(snowMusic)) StopMusicStream(snowMusic);
            }
        }
        // Start screen
        if (!gameStarted)
        {
            if (!showTutorial)
            {
                if (IsKeyPressed(KEY_ONE))
                {
                    selectedEnvironment = 1;
                    PlaySound(buttonSfx);
                }

                if (IsKeyPressed(KEY_TWO))
                {
                    selectedEnvironment = 2;
                    PlaySound(buttonSfx);
                }
                if (IsKeyPressed(KEY_ENTER) && selectedEnvironment != 0)
                {
                    showTutorial = true;
                }
            }
            else // showTutorial == true
            {
                if (IsKeyPressed(KEY_ENTER))
                {
                    showTutorial = false;
                    gameStarted = true;

                    dinoY = ground;
                    dinoSpeed = 0;
                    isJumping = false;

                    lastWeatherPhase = -1;
                    weatherTransitionActive = false;
                    weatherTransitionProgress = 1.0f;
                    cloudAlpha = 0.0f;
                    cloudEntering = false;
                    cloudLeaving = false;
                    leftCloudOffset = -500.0f;
                    rightCloudOffset = 800.0f;
                }
            }
        }
        if (gameStarted && IsKeyDown(KEY_DOWN) && !isJumping)
        {
            isCrouching = true;
        }
        else
        {
            isCrouching = false;
        }

        // Only update game if NOT game over
        if (!gameOver && gameStarted)
        {
            // ===== PLAYER INPUT =====
            if (IsKeyPressed(KEY_SPACE))
            {
                if (dinoY == ground)
                {
                    dinoSpeed = -jumpPower;
                    isJumping = true;
                    PlaySound(jumpSfx);
                }
            }

            isMoving = false;

            if (bigMountainX <= -800)
            {
                bigMountainX = 800;
            }

            if (smallMountainX <= -800)
            {
                smallMountainX = 800;
            }
            if (IsKeyDown(KEY_RIGHT))
            {
                dinoX = dinoX + 5;
                isMoving = true;
            }

            if (IsKeyDown(KEY_LEFT))
            {
                dinoX = dinoX - 5;
                isMoving = true;
            }

            // ===== PHYSICS =====
            dinoSpeed = dinoSpeed + gravity;
            dinoY = dinoY + dinoSpeed;

            // =====  DINO COLLISION WITH GROUND =====
            if (dinoY >= ground)
            {
                if (isJumping) PlaySound(landingSfx);
                dinoY = ground;
                dinoSpeed = 0;
                isJumping = false;
            }

            // ===== DINO BOUNDARIES =====
            if (dinoX < 0)
            {
                dinoX = 0;
            }
            if (dinoX > 800 - dinoWidth)
            {
                dinoX = 800 - dinoWidth;
            }

            // ===== DINO RUN ANIMATION =====
            if (!isJumping && isMoving)
            {
                dinoRunCounter++;
                if (dinoRunCounter > 10)
                {
                    dinoRunFrame = (dinoRunFrame + 1) % 2;
                    dinoRunCounter = 0;
                }
            }
            else
            {
                dinoRunFrame = 0;
                dinoRunCounter = 0;
            }

            // ===== CACTUS MOVEMENT =====
            cactusX = cactusX - cactusSpeed;
            if (secondCactusActive)
            {
                cactus2X = cactus2X - cactusSpeed;
            }

            // ===== BIRD MOVEMENT & ANIMATION =====
            if (birdActive)
            {
                birdX = birdX - birdSpeed;
                birdAnimationCounter++;
                if (birdAnimationCounter > 15)
                {
                    birdAnimationType = (birdAnimationType + 1) % 3;
                    birdAnimationCounter = 0;
                }
            }

            if (summerPhase == 3 || summerPhase == 4) // Rain phases
            {
                for (int i = 0; i < rainCount; i++)
                {
                    // Fall down
                    rain[i].y += rain[i].speed * 0.7f;

                    // Slight wind towards left
                    rain[i].x -= 0.8f;
                    if (rain[i].x < -50)
                    {
                        rain[i].x = screenWidth + 50;
                    }

                    // Respawn when drop leaves screen
                    if (rain[i].y > screenHeight)
                    {
                        rain[i].y = GetRandomValue(95, 150);
                        rain[i].x = GetRandomValue(-100, screenWidth + 100);
                    }
                }
            }
            // ===== LIGHTNING LOGIC =====
            int updateCycleScore = score % 100;
            if (score == 0) updateCycleScore = 0;
            else if (updateCycleScore == 0) updateCycleScore = 100;

            if (selectedEnvironment == 1 && updateCycleScore >= 61 && updateCycleScore <= 85)
            {
                if (lightningFlashAlpha <= 0.0f && GetRandomValue(0, 1000) < 5)
                {
                    lightningFlashAlpha = 1.0f;
                    PlaySound(thunderSfx);
                    lightningPath.clear();
                    Vector2 current = { (float)GetRandomValue(100, 700), -10.0f };
                    while (current.y < 350)
                    {
                        Vector2 next = { current.x + GetRandomValue(-40, 40), current.y + GetRandomValue(20, 60) };
                        lightningPath.push_back({current, next});
                        current = next;
                    }
                }
            }
            if (lightningFlashAlpha > 0.0f)
            {
                if (updateCycleScore > 85 || selectedEnvironment != 1) {
                    lightningFlashAlpha = 0.0f;
                } else {
                    lightningFlashAlpha -= GetFrameTime() * 2.5f;
                    if (lightningFlashAlpha < 0.0f) lightningFlashAlpha = 0.0f;
                }
            }
            // ===== CACTUS 1 AND BIRD SPAWN RESET =====
            if (cactusX < -cactusWidth)
            {
                score = score + 1;
                if (score > highscore)
                {
                    highscore = score;
                }

                if (score == nextBirdSpawnScore)
                {
                    // It's time for a bird!
                    birdActive = true;
                    birdX = 800;
                    isDoubleBird = IsDoubleBirdScore(score);
                    // Single bird forces jump, double bird (stacked) forces crouch
                    birdY = isDoubleBird ? 180 : 300; 
                    birdAnimationType = 0;
                    birdAnimationCounter = 0;

                    // Push cactus back just enough so it doesn't overlap with the bird.
                    // Since bird is generally faster or equal to cactus, a fixed gap is enough.
                    cactusX = 800 + GetRandomValue(450, 650);
                }
                else
                {
                    cactusX = 800 + GetRandomValue(0, 300);
                }

                cactusType = ChooseCactusType(score);
                SetCactusSize(cactusType, cactusWidth, cactusHeight);
                cactusY = 360 - cactusHeight;

                if (score % 10 == 0 && score != 0 && cactusSpeed < 15)
                {
                    cactusSpeed++;
                    if (cactusSpeed % 2 == 0) // Increase bird speed every 2 cactus speed increases
                    {
                        birdSpeed++;
                    }
                }

                int spawnChance = 0;
                if (score < 10)
                    spawnChance = 20;
                else if (score < 20)
                    spawnChance = 40;
                else
                    spawnChance = 60;

                // Spawn cactus 2 only if there isn't already one on screen
                if (!secondCactusActive)
                {
                    secondCactusActive = (GetRandomValue(1, 100) <= spawnChance);

                    if (secondCactusActive)
                    {
                        cactus2Type = ChooseCactusType(score);
                        SetCactusSize(cactus2Type, cactus2Width, cactus2Height);
                        cactus2Y = 360 - cactus2Height;

                        int gap = GetRandomValue(0, 40);

                        cactus2X = cactusX + cactusWidth + gap;
                    }
                }
            }

            // ===== CACTUS 2 RESET =====
            if (secondCactusActive && cactus2X < -cactus2Width)
            {
                secondCactusActive = false;
                cactus2X = 1400;
            }

            // ===== BIRD RESET =====
            if (birdActive && birdX < -birdWidth)
            {
                birdActive = false;
                score = score + 1;

                if (score > highscore)
                {
                    highscore = score;
                }
                
                nextBirdSpawnScore = GetNextBirdScore(score); // Set next spawn using specific logic
            }

            // ===== COLLISION DETECTION - CACTUS 1 =====
            bool horizontalOverlap = cactusX + cactusWidth > dinoX &&
                                     cactusX < dinoX + dinoWidth;
            bool verticalOverlap = dinoY + dinoHeight > cactusY &&
                                   dinoY < cactusY + cactusHeight;

            // ===== COLLISION DETECTION - CACTUS 2 =====
            bool horizontalOverlap2 = false;
            bool verticalOverlap2 = false;
            if (secondCactusActive)
            {
                horizontalOverlap2 = cactus2X + cactus2Width > dinoX &&
                                     cactus2X < dinoX + dinoWidth;
                verticalOverlap2 = dinoY + dinoHeight > cactus2Y &&
                                   dinoY < cactus2Y + cactus2Height;
            }

            // ===== COLLISION DETECTION - BIRD =====
            int currentBirdTotalHeight = isDoubleBird ? (birdHeight * 2 + 5) : birdHeight;
            bool birdHorizontal = birdX + birdWidth > dinoX &&
                                  birdX < dinoX + dinoWidth;
            bool birdVertical = dinoY + dinoHeight > birdY &&
                                dinoY < birdY + currentBirdTotalHeight;

            // ===== GAME OVER =====
            if ((horizontalOverlap && verticalOverlap) ||
                (horizontalOverlap2 && verticalOverlap2) ||
                (birdActive && birdHorizontal && birdVertical))
            {
                if (!gameOver) {
                    PlaySound(gameOverSfx);
                    shakeDuration = 0.3f;
                }
                gameOver = true;
                dinoSpeed = 0;
            }

            // ===== WEATHER & CELESTIAL PHASE LOGIC =====
            float dt = GetFrameTime();
            int cycleScore = score % 100;
            if (score == 0)
                cycleScore = 0;
            else if (cycleScore == 0)
                cycleScore = 100;

            // ===== CLOUD MOVEMENT =====
            if (selectedEnvironment == 1)
            {
                if (summerPhase == 3 || summerPhase == 4) // Rain phases only
                {
                    cloud1X -= 1;
                    cloud2X -= 1;
                    cloud3X -= 1;
                }
            }
            else if (selectedEnvironment == 2)
            {
                // Winter: gentle constant cloud drift
                cloud1X -= 1.0f;
                cloud2X -= 1.0f;
                cloud3X -= 1.0f;

                if (cycleScore <= 50) // Respawn clouds only during 0-54
                {
                    float maxCloudX = std::fmax((float)cloud1X, std::fmax((float)cloud2X, (float)cloud3X));
                    float spawnBaseX = std::fmax(850.0f, maxCloudX + 150.0f);

                    if (cloud1X < -50)
                    {
                        cloud1X = spawnBaseX + GetRandomValue(0, 100);
                        cloud1Y = GetRandomValue(40, 150);
                        spawnBaseX = cloud1X + 150.0f;
                    }
                    if (cloud2X < -50)
                    {
                        cloud2X = spawnBaseX + GetRandomValue(0, 100);
                        cloud2Y = GetRandomValue(40, 150);
                        spawnBaseX = cloud2X + 150.0f;
                    }
                    if (cloud3X < -50)
                    {
                        cloud3X = spawnBaseX + GetRandomValue(0, 100);
                        cloud3Y = GetRandomValue(40, 150);
                    }
                }

                // Snowfall always updates so remaining snow falls off screen naturally
                for (int i = 0; i < snowCount; i++)
                {
                    if (cycleScore < 61)
                    {
                        snow[i].y = screenHeight + 100; // Force them completely off-screen
                    }

                    snow[i].y += snow[i].speed;
                    snow[i].x -= 0.5f + sinf(snow[i].driftPhase + snow[i].y * 0.02f) * 0.5f; // Realistic wind

                    if (snow[i].y > screenHeight || snow[i].x < -10)
                    {
                        if (cycleScore >= 61 && cycleScore <= 90)
                        {
                            snow[i].y = GetRandomValue(-screenHeight, -10);
                            snow[i].x = GetRandomValue(0, screenWidth + 50);
                        }
                    }
                }
            }

            // Determine weather phase based on user schedule:
            // 0-20: Day, 21-40: Night, 41-60: Day, 61-80: Day Rain, 81-90: Rain Night, 91-100: Night
            if (selectedEnvironment == 1)
            {
                int weatherPhase;
                if (cycleScore <= 20)
                    weatherPhase = 0; // Day
                else if (cycleScore <= 40)
                    weatherPhase = 1; // Night
                else if (cycleScore <= 60)
                    weatherPhase = 2; // Day
                else if (cycleScore <= 80)
                    weatherPhase = 3; // Day Rain
                else if (cycleScore <= 88)
                    weatherPhase = 4; // Rain Night
                else
                    weatherPhase = 5; // Night
                                      // Cloud Enter Animation
                static bool cloudsEnteredThisCycle = false;
                if (cycleScore == 59 && !cloudsEnteredThisCycle)
                {
                    cloudEntering = true;
                    cloudLeaving = false;
                    cloudsEnteredThisCycle = true;
                }

                if (cycleScore <= 20)
                {
                    cloudsEnteredThisCycle = false;
                }

                // Cloud Leave Animation
                static bool cloudsLeftThisCycle = false;

                if (cycleScore >= 88 && cycleScore <= 89 && !cloudsLeftThisCycle)
                {
                    cloudLeaving = true;
                    cloudEntering = false;
                    cloudsLeftThisCycle = true;
                }

                if (cycleScore <= 20)
                {
                    cloudsLeftThisCycle = false;
                }

                // Update summerPhase for drawing
                summerPhase = weatherPhase;

                // ===== WEATHER TRANSITION DETECTION =====
                // Trigger transition whenever weather phase changes
                if (weatherPhase != lastWeatherPhase)
                {
                    weatherTransitionActive = true;
                    weatherTransitionProgress = 0.0f;
                    weatherTransitionFromPhase = lastWeatherPhase;
                    weatherTransitionToPhase = weatherPhase;
                }

                // Update lastWeatherPhase at end of game update
                lastWeatherPhase = weatherPhase;

                // ===== WEATHER TRANSITION ANIMATION =====
                if (weatherTransitionActive)
                {
                    weatherTransitionProgress += dt / weatherTransitionDuration;
                    if (weatherTransitionProgress >= 1.0f)
                    {
                        weatherTransitionProgress = 1.0f;
                        weatherTransitionActive = false;
                    }
                }

                // Determine celestial phase (which body moves)
                int celestialPhase;
                if (cycleScore <= 20)
                    celestialPhase = 1; // Sun 0-20
                else if (cycleScore <= 40)
                    celestialPhase = 2; // Moon 21-40
                else if (cycleScore <= 80)
                    celestialPhase = 3; // Sun 41-80 (merged, continuous motion)
                else
                    celestialPhase = 4; // Moon 81-100

                // Reset progress on phase transition
                if (celestialPhase != lastCyclePhase)
                {
                    lastCyclePhase = celestialPhase;
                    sunMoveProgress = 0.0f;
                    moonMoveProgress = 0.0f;
                    // Set starting positions
                    if (celestialPhase == 1)
                        sunX = 750; // Sun starts at 750 for 0-20
                    else if (celestialPhase == 2)
                        moonX = 850;
                    else if (celestialPhase == 3)
                        sunX = 750; // Sun starts at 750 for 41-80 (merged)
                    else if (celestialPhase == 4)
                        moonX = 850;
                }

                // Phase durations: 60pts for 20-score, 120pts for 40-score
                float phaseDuration = 60.0f;

                if (celestialPhase == 2) // Moon 21-40
                    phaseDuration = 49.0f;
                else if (celestialPhase == 3) // Sun 41-80 (40 points, merged)
                    phaseDuration = 100.0f;
                else if (celestialPhase == 4) // Moon 81-100
                    phaseDuration = 28.0f;

                // Animate celestial bodies
                if (celestialPhase == 1) // Sun 0-20
                {
                    float nextProgress = sunMoveProgress + dt / phaseDuration;
                    sunMoveProgress = (nextProgress < 1.0f) ? nextProgress : 1.0f;
                    sunX = 750 - sunMoveProgress * 830; // from 750 to -80
                }
                else if (celestialPhase == 2) // Moon 21-40
                {
                    float nextProgress = moonMoveProgress + dt / phaseDuration;
                    moonMoveProgress = (nextProgress < 1.0f) ? nextProgress : 1.0f;
                    moonX = 750 - moonMoveProgress * 930; // from 850 to -80
                }
                else if (celestialPhase == 3) // Sun 41-80 (merged, continuous)
                {
                    float nextProgress = sunMoveProgress + dt / phaseDuration;
                    sunMoveProgress = (nextProgress < 1.0f) ? nextProgress : 1.0f;
                    sunX = 750 - sunMoveProgress * 830; // from 750 to -80
                }
                else // celestialPhase == 4 // Moon 81-100
                {
                    float nextProgress = moonMoveProgress + dt / phaseDuration;
                    moonMoveProgress = (nextProgress < 1.0f) ? nextProgress : 1.0f;
                    moonX = 750 - moonMoveProgress * 930; // from 850 to -80
                }
            }
            else if (selectedEnvironment == 2)
            {
                // ===== WINTER WEATHER =====

                int weatherPhase;

                if (cycleScore <= 20)
                    weatherPhase = 0; // Day
                else if (cycleScore <= 40)
                    weatherPhase = 1; // Night
                else if (cycleScore <= 60)
                    weatherPhase = 0; // Day
                else if (cycleScore <= 80)
                    weatherPhase = 1; // Night
                else
                    weatherPhase = 2; // Cloudy Day

                // Used by drawing code
                summerPhase = weatherPhase;

                // ===== WEATHER TRANSITION =====
                if (weatherPhase != lastWeatherPhase)
                {
                    weatherTransitionActive = true;
                    weatherTransitionProgress = 0.0f;
                    weatherTransitionFromPhase = lastWeatherPhase;
                    weatherTransitionToPhase = weatherPhase;
                }

                lastWeatherPhase = weatherPhase;

                // ===== WEATHER FADE =====
                if (weatherTransitionActive)
                {
                    weatherTransitionProgress += dt / weatherTransitionDuration;

                    if (weatherTransitionProgress >= 1.0f)
                    {
                        weatherTransitionProgress = 1.0f;
                        weatherTransitionActive = false;
                    }
                }
            }
        } // End game update guard

        // ===== RESTART LOGIC (outside game update) =====
        if (IsKeyPressed(KEY_R) && gameOver)
        {
            gameOver = false;
            dinoX = 100;
            dinoY = ground;
            dinoSpeed = 0;
            isJumping = false;
            cactusX = 800 + GetRandomValue(0, 300);
            cactus2X = 1400;
            score = 0;
            cactusSpeed = 5;
            secondCactusActive = false;
            birdActive = false;
            birdX = 800;
            birdY = 220;
            birdAnimationType = 0;
            birdAnimationCounter = 0;
            nextBirdSpawnScore = 15;
            birdSpawnedAtThisScore = false;
            cloud1X = 800;
            cloud2X = 1100;
            cloud3X = 1400;
            cloud1Y = GetRandomValue(40, 150);
            cloud2Y = GetRandomValue(40, 150);
            cloud3Y = GetRandomValue(40, 150);
            sunMoveProgress = 0.0f;
            moonMoveProgress = 0.0f;
            lastCyclePhase = 0;
            sunX = 850;
            moonX = 850;
            // Reset shared weather state so cycle restarts cleanly
            lastWeatherPhase = -1;
            weatherTransitionActive = false;
            weatherTransitionProgress = 1.0f;
            cloudAlpha = 0.0f;
            cloudEntering = false;
            cloudLeaving = false;
            leftCloudOffset = -500.0f;
            rightCloudOffset = 800.0f;
            gameStarted = true;
        }

        // ===== DRAWING (always runs) =====
        BeginDrawing();

        if (shakeDuration > 0.0f)
        {
            shakeDuration -= GetFrameTime();
            camera.target = (Vector2){ 400.0f, 210.0f };
            camera.offset = (Vector2){ 400.0f + (float)GetRandomValue(-10, 10), 210.0f + (float)GetRandomValue(-10, 10) };
            camera.zoom = 1.03f;
        }
        else
        {
            camera.target = (Vector2){ 0.0f, 0.0f };
            camera.offset = (Vector2){ 0.0f, 0.0f };
            camera.zoom = 1.0f;
        }
        BeginMode2D(camera);
        
        // cycleScore for drawing (mirrors value from update, or 0 if not yet started)
        int cycleScore = 0;
        if (gameStarted)
        {
            cycleScore = score % 100;
            if (score == 0)
                cycleScore = 0;
            else if (cycleScore == 0)
                cycleScore = 100;
        }
        bool glowAndStickPhase = (selectedEnvironment == 1)
            ? ((cycleScore >= 21 && cycleScore <= 40) || (cycleScore >= 81 && cycleScore <= 100))
            : ((cycleScore >= 21 && cycleScore <= 40) || (cycleScore >= 61 && cycleScore <= 80));

        // ---------- Clouds Enter ----------
        if (gameStarted && cloudEntering)
        {
            if (leftCloudOffset < 0)
                leftCloudOffset += 6.0f;
            if (rightCloudOffset > 250)
                rightCloudOffset -= 6.0f;
            if (cloudAlpha < 1.0f)
                cloudAlpha += 0.02f;
            if (leftCloudOffset >= 0 && rightCloudOffset <= 250)
            {
                leftCloudOffset = 0;
                rightCloudOffset = 250;
                cloudAlpha = 1.0f;
                cloudEntering = false;
            }
        }
        // ---------- Clouds Leave ----------
        if (gameStarted && cloudLeaving)
        {
            if (leftCloudOffset > -500)
                leftCloudOffset -= 6.0f;
            if (rightCloudOffset < 800)
                rightCloudOffset += 6.0f;
            if (cloudAlpha > 0.0f)
                cloudAlpha -= 0.02f;
            if (leftCloudOffset <= -500 && rightCloudOffset >= 800)
            {
                leftCloudOffset = -500;
                rightCloudOffset = 800;
                cloudAlpha = 0.0f;
                cloudLeaving = false;
            }
        }

        if (!gameStarted && !showTutorial)
        {
            ClearBackground(BLACK);

            // Scale to fit maintaining aspect ratio (1419x736 -> 800x420)
            float scale = fminf((float)screenWidth / menu.width, (float)screenHeight / menu.height);
            float destWidth = menu.width * scale;
            float destHeight = menu.height * scale;
            float destX = (screenWidth - destWidth) / 2.0f;
            float destY = (screenHeight - destHeight) / 2.0f;

            // Draw scaled menu background
            DrawTexturePro(menu,
                           (Rectangle){0.0f, 0.0f, (float)menu.width, (float)menu.height},
                           (Rectangle){destX, destY, destWidth, destHeight},
                           (Vector2){0.0f, 0.0f},
                           0.0f,
                           WHITE);

            // Pulse animation timer
            static float pulseTimer = 0.0f;
            pulseTimer += GetFrameTime() * 4.0f;
            float pulse = (sinf(pulseTimer) + 1.0f) / 2.0f; // 0.0f to 1.0f

            // Update scale micro-animations
            static float summerScale = 1.0f;
            static float winterScale = 1.0f;
            float targetSummerScale = (selectedEnvironment == 1) ? 1.08f : 1.0f;
            float targetWinterScale = (selectedEnvironment == 2) ? 1.08f : 1.0f;
            float dt = GetFrameTime();
            summerScale += (targetSummerScale - summerScale) * 12.0f * dt;
            winterScale += (targetWinterScale - winterScale) * 12.0f * dt;

            // Mapped button coordinates in 1419x736 texture space
            float summerTexX = 386.0f;
            float summerTexY = 455.0f;
            float summerTexW = 305.0f;
            float summerTexH = 99.0f;

            float winterTexX = 731.0f;
            float winterTexY = 455.0f;
            float winterTexW = 305.0f;
            float winterTexH = 99.0f;

            // Translate to screen coordinates
            Rectangle summerScreenRec = {
                destX + (summerTexX / 1419.0f) * destWidth,
                destY + (summerTexY / 736.0f) * destHeight,
                (summerTexW / 1419.0f) * destWidth,
                (summerTexH / 736.0f) * destHeight};

            Rectangle winterScreenRec = {
                destX + (winterTexX / 1419.0f) * destWidth,
                destY + (winterTexY / 736.0f) * destHeight,
                (winterTexW / 1419.0f) * destWidth,
                (winterTexH / 736.0f) * destHeight};

            // Custom Button drawing helper
            auto DrawCustomButton = [&](Rectangle baseRec, float scaleVal, bool selected, Color themeColor, const char *text, bool isSummer)
            {
                // Scale rectangle centered
                float newWidth = baseRec.width * scaleVal;
                float newHeight = baseRec.height * scaleVal;
                float newX = baseRec.x - (newWidth - baseRec.width) / 2.0f;
                float newY = baseRec.y - (newHeight - baseRec.height) / 2.0f;
                Rectangle rec = {newX, newY, newWidth, newHeight};

                // Draw button background
                Color bgColor = selected ? themeColor : BLACK;
                Color borderColor = selected ? themeColor : (Color){215, 200, 180, 255};

                // Rounded button backing (covers the background image button)
                DrawRectangleRounded(rec, 0.35f, 16, bgColor);

                // Borders
                DrawRectangleRoundedLines(rec, 0.35f, 16, borderColor);

                if (selected)
                {
                    // Draw outer glow layers
                    Rectangle outerRec1 = {rec.x - 2, rec.y - 2, rec.width + 4, rec.height + 4};
                    Rectangle outerRec2 = {rec.x - 4, rec.y - 4, rec.width + 8, rec.height + 8};
                    DrawRectangleRoundedLines(outerRec1, 0.35f, 16, Fade(themeColor, 0.35f * pulse));
                    DrawRectangleRoundedLines(outerRec2, 0.35f, 16, Fade(themeColor, 0.15f * pulse));
                }
                else
                {
                    // Faint pulsing border for interactive feel when none is selected
                    DrawRectangleRoundedLines(rec, 0.35f, 16, Fade(borderColor, 0.6f + 0.3f * pulse));
                }

                // Render procedural icons and text inside the button
                int fontSize = rec.height * 0.28f;
                int textWidth = MeasureText(text, fontSize);

                float contentWidth = textWidth + 30.0f; // text width + icon + spacing
                float startX = rec.x + (rec.width - contentWidth) / 2.0f;
                float centerY = rec.y + rec.height / 2.0f;

                Color textColor = selected ? WHITE : (Color){200, 190, 180, 255};
                Color iconColor = selected ? WHITE : (Color){215, 200, 180, 255};

                if (isSummer)
                {
                    // Procedural Sun: circle with lines for rays
                    DrawCircle(startX + 10, centerY, 6, iconColor);
                    for (int a = 0; a < 360; a += 45)
                    {
                        float rad = a * DEG2RAD;
                        Vector2 start = {startX + 10 + cosf(rad) * 8, centerY + sinf(rad) * 8};
                        Vector2 end = {startX + 10 + cosf(rad) * 11, centerY + sinf(rad) * 11};
                        DrawLineEx(start, end, 1.5f, iconColor);
                    }
                }
                else
                {
                    // Procedural Snowflake: intersecting lines with terminal ticks
                    DrawLineEx((Vector2){startX + 4, centerY}, (Vector2){startX + 16, centerY}, 2.0f, iconColor);
                    DrawLineEx((Vector2){startX + 10, centerY - 6}, (Vector2){startX + 10, centerY + 6}, 2.0f, iconColor);
                    DrawLineEx((Vector2){startX + 6, centerY - 4}, (Vector2){startX + 14, centerY + 4}, 1.5f, iconColor);
                    DrawLineEx((Vector2){startX + 6, centerY + 4}, (Vector2){startX + 14, centerY - 4}, 1.5f, iconColor);
                }

                // Draw label next to icon
                DrawText(text, startX + 25.0f, centerY - fontSize / 2.0f, fontSize, textColor);
            };

            // Render custom button overlays on top of the menu image buttons
            DrawCustomButton(summerScreenRec, summerScale, selectedEnvironment == 1, ORANGE, "SUMMER", true);
            DrawCustomButton(winterScreenRec, winterScale, selectedEnvironment == 2, SKYBLUE, "WINTER", false);

            // Pulse line under "Press ENTER to Start" if environment is selected
            if (selectedEnvironment != 0)
            {
                Color themeColor = (selectedEnvironment == 1) ? ORANGE : SKYBLUE;
                Color glowColor = LerpColor(themeColor, WHITE, pulse);
                float lineX1 = destX + destWidth / 2.0f - 140.0f;
                float lineX2 = destX + destWidth / 2.0f + 140.0f;
                float lineY = destY + (680.0f / 736.0f) * destHeight;

                DrawLineEx((Vector2){lineX1, lineY}, (Vector2){lineX2, lineY}, 2.5f, Fade(glowColor, 0.4f + 0.4f * pulse));
            }
        }
        else
        {
            ClearBackground(WHITE);
            Color nightBG = (Color){20, 30, 60, 120};      // strong blue tint (background feel)
            Color nightObject = (Color){80, 100, 160, 60}; // lighter tint for objects
            // ==================== DRAW ENVIRONMENT ====================
            if (selectedEnvironment == 1)
            {
                // BACKGROUND tint system based on weather phase
                Color daySkyTint = WHITE;
                Color cloudySkyTint = (Color){185, 190, 200, 255}; // Light gray-blue
                Color nightSkyTint = (Color){60, 60, 100, 255};

                auto GetTargetSkyTint = [&](int phase) -> Color
                {
                    if (phase == 0)
                        return daySkyTint;
                    if (phase == 1)
                        return nightSkyTint;
                    if (phase == 2)
                        return LerpColor(daySkyTint, cloudySkyTint, cloudAlpha);
                    if (phase == 3)
                        return cloudySkyTint;
                    if (phase == 4 || phase == 5)
                        return nightSkyTint;
                    return daySkyTint;
                };

                Color skyTint = daySkyTint;

                if (weatherTransitionActive)
                {
                    Color fromSky = GetTargetSkyTint(weatherTransitionFromPhase);
                    Color toSky = GetTargetSkyTint(weatherTransitionToPhase);
                    skyTint = LerpColor(fromSky, toSky, weatherTransitionProgress);
                }
                else
                {
                    skyTint = GetTargetSkyTint(summerPhase);
                }

                DrawTexturePro(
                    desertBG,
                    (Rectangle){0, 0, (float)desertBG.width, (float)desertBG.height},
                    (Rectangle){0, 0, 800, 420},
                    (Vector2){0, 0},
                    0,
                    skyTint);

                // ===== LIGHTNING DRAW =====
                if (lightningFlashAlpha > 0.0f && cycleScore <= 85 && cycleScore >= 61)
                {
                    DrawRectangle(0, 0, 800, 420, Fade(WHITE, lightningFlashAlpha * 0.4f));
                    for (size_t i = 0; i < lightningPath.size(); i++)
                    {
                        DrawLineEx(lightningPath[i].start, lightningPath[i].end, 3.0f, Fade(WHITE, lightningFlashAlpha));
                        DrawLineEx(lightningPath[i].start, lightningPath[i].end, 8.0f, Fade(SKYBLUE, lightningFlashAlpha * 0.5f));
                    }
                }

                // 🌞 SUN / 🌙 MOON SWITCH - draw celestial body based on phase
                if (cycleScore <= 20 || (cycleScore > 40 && cycleScore <= 80))
                {
                    // SUN visible: 0-20, 41-60, 61-80
                    DrawCircle(sunX + 40, 70, 70, Fade(YELLOW, 0.08f));
                    DrawCircle(sunX + 40, sunY + 40, 55, Fade(ORANGE, 0.12f));
                    DrawCircle(sunX + 40, sunY + 40, 40, Fade(YELLOW, 0.18f));
                    DrawTexturePro(
                        sunTexture,
                        (Rectangle){0, 0, (float)sunTexture.width, (float)sunTexture.height},
                        (Rectangle){sunX, 30, 80, 80},
                        (Vector2){0, 0},
                        0,
                        WHITE);
                }
                else
                {
                    // Moon Glow
                    DrawCircle(moonX + 35, 85, 70, Fade((Color){150, 200, 255, 255}, 0.05f));
                    DrawCircle(moonX + 35, 85, 55, Fade((Color){200, 225, 255, 255}, 0.08f));
                    DrawCircle(moonX + 35, 85, 40, Fade((Color){235, 245, 255, 255}, 0.12f));
                    DrawTexturePro(
                        moonSummer,
                        (Rectangle){0, 0, (float)moonSummer.width, (float)moonSummer.height},
                        (Rectangle){moonX, 50, 70, 70},
                        (Vector2){0, 0},
                        0,
                        WHITE);
                }
            }
            else if (selectedEnvironment == 2)
            {
                Color daySkyTint = WHITE;
                Color cloudySkyTint = (Color){200, 210, 220, 255}; // Cloudy dark themed daylight
                Color nightSkyTint = (Color){90, 100, 150, 255};

                Color skyTint = daySkyTint;

                if (weatherTransitionActive)
                {
                    Color fromSky = (weatherTransitionFromPhase == 1) ? nightSkyTint : (weatherTransitionFromPhase == 2) ? cloudySkyTint
                                                                                                                         : daySkyTint;

                    Color toSky = (weatherTransitionToPhase == 1) ? nightSkyTint : (weatherTransitionToPhase == 2) ? cloudySkyTint
                                                                                                                   : daySkyTint;

                    skyTint = LerpColor(fromSky, toSky, weatherTransitionProgress);
                }
                else
                {
                    skyTint = (summerPhase == 1) ? nightSkyTint : (summerPhase == 2) ? cloudySkyTint
                                                                                     : daySkyTint;
                }

                DrawTexturePro(
                    snowBG,
                    (Rectangle){0, 0, (float)snowBG.width, (float)snowBG.height},
                    (Rectangle){0, 0, 800, 420},
                    (Vector2){0, 0},
                    0,
                    skyTint);
            }
            // ===== DRAW GROUND =====
            if (selectedEnvironment == 1)
            {
                Color dayGroundTint = WHITE;
                Color cloudyGroundTint = (Color){185, 185, 185, 255};
                Color nightGroundTint = (Color){100, 110, 140, 255};

                auto GetTargetGroundTint = [&](int phase) -> Color
                {
                    if (phase == 0)
                        return dayGroundTint;
                    if (phase == 1)
                        return nightGroundTint;
                    if (phase == 2)
                        return LerpColor(dayGroundTint, cloudyGroundTint, cloudAlpha);
                    if (phase == 3)
                        return cloudyGroundTint;
                    if (phase == 4 || phase == 5)
                        return nightGroundTint;
                    return dayGroundTint;
                };

                Color groundTint = dayGroundTint;

                // ===== Weather Transition =====
                if (weatherTransitionActive)
                {
                    Color fromGround = GetTargetGroundTint(weatherTransitionFromPhase);
                    Color toGround = GetTargetGroundTint(weatherTransitionToPhase);
                    groundTint = LerpColor(fromGround, toGround, weatherTransitionProgress);
                }
                else
                {
                    groundTint = GetTargetGroundTint(summerPhase);
                }

                // ===== Draw Ground =====
                DrawTexturePro(
                    soilGround,
                    (Rectangle){0, 0, (float)soilGround.width, (float)soilGround.height},
                    (Rectangle){0, 340, 800, 80},
                    (Vector2){0, 0},
                    0,
                    groundTint);
            }
            else if (selectedEnvironment == 2)
            {
                // ===== Winter ground: smooth Day/Night tint =====
                Color dayGroundTint = WHITE;
                Color cloudyGroundTint = (Color){200, 210, 220, 255}; // Cloudy dark themed daylight
                Color nightGroundTint = (Color){140, 150, 185, 255};

                Color groundTint = dayGroundTint;

                if (weatherTransitionActive)
                {
                    Color fromGround = (weatherTransitionFromPhase == 1) ? nightGroundTint : (weatherTransitionFromPhase == 2) ? cloudyGroundTint
                                                                                                                               : dayGroundTint;

                    Color toGround = (weatherTransitionToPhase == 1) ? nightGroundTint : (weatherTransitionToPhase == 2) ? cloudyGroundTint
                                                                                                                         : dayGroundTint;

                    groundTint = LerpColor(fromGround, toGround, weatherTransitionProgress);
                }
                else
                {
                    groundTint = (summerPhase == 1) ? nightGroundTint : (summerPhase == 2) ? cloudyGroundTint
                                                                                           : dayGroundTint;
                }

                DrawTexturePro(
                    snowGround,
                    (Rectangle){0, 0, (float)snowGround.width, (float)snowGround.height},
                    (Rectangle){0, 340, 800, 80},
                    (Vector2){0, 0},
                    0,
                    groundTint);
            }

            // Draw ground line
            Color groundColor = isNight ? WHITE : BLACK;

            // Draw clouds
            if (selectedEnvironment == 2)
            {
                DrawCircle(cloud1X, cloud1Y, 20, LIGHTGRAY);
                DrawCircle(cloud1X + 20, cloud1Y, 20, LIGHTGRAY);
                DrawCircle(cloud1X + 40, cloud1Y, 20, LIGHTGRAY);

                DrawCircle(cloud2X, cloud2Y, 20, LIGHTGRAY);
                DrawCircle(cloud2X + 20, cloud2Y, 20, LIGHTGRAY);
                DrawCircle(cloud2X + 40, cloud2Y, 20, LIGHTGRAY);

                DrawCircle(cloud3X, cloud3Y, 20, LIGHTGRAY);
                DrawCircle(cloud3X + 20, cloud3Y, 20, LIGHTGRAY);
                DrawCircle(cloud3X + 40, cloud3Y, 20, LIGHTGRAY);

                // ================= SNOWFALL =================
                Color snowColor = WHITE;
                if (summerPhase == 1) // Night (61-80)
                {
                    snowColor = (Color){200, 220, 255, 200}; // Slightly blue, transparent at night
                }
                else // Day (81-100)
                {
                    snowColor = (Color){255, 255, 255, 255}; // Bright white in day
                }

                for (int i = 0; i < snowCount; i++)
                {
                    if (snow[i].y > -20 && snow[i].y < screenHeight)
                    {
                        DrawCircle(snow[i].x, snow[i].y, snow[i].size, snowColor);
                    }
                }
            }
            // ================= RAIN CLOUDS (Summer only) =================
            if (selectedEnvironment == 1 &&
                ((cycleScore >= 59 && cycleScore <= 90) ||
                 cloudEntering ||
                 cloudLeaving))
            {
                // ================= TOP ROW =================

                // Left Half
                for (int x = -40; x < 400; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){leftCloudOffset + x, -60},
                        0.0f,
                        0.45f,
                        Fade(WHITE, cloudAlpha));
                }

                // Right Half
                for (int x = 220; x < screenWidth + 200; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){rightCloudOffset + x, -60},
                        0.0f,
                        0.45f,
                        Fade(WHITE, cloudAlpha));
                }

                // ================= MIDDLE ROW =================

                // Left Half
                for (int x = -150; x < 400; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){leftCloudOffset + x, -15},
                        0.0f,
                        0.45f,
                        Fade(WHITE, cloudAlpha * 0.9f));
                }

                // Right Half
                for (int x = 110; x < screenWidth + 200; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){rightCloudOffset + x, -15},
                        0.0f,
                        0.45f,
                        Fade(WHITE, cloudAlpha * 0.9f));
                }

                // ================= BOTTOM ROW =================

                // Left Half
                for (int x = -50; x < 400; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){leftCloudOffset + x, 30},
                        0.0f,
                        0.40f,
                        Fade(WHITE, cloudAlpha * 0.85f));
                }

                // Right Half
                for (int x = 210; x < screenWidth + 200; x += 250)
                {
                    DrawTextureEx(
                        rainycloud,
                        (Vector2){rightCloudOffset + x, 30},
                        0.0f,
                        0.40f,
                        Fade(WHITE, cloudAlpha * 0.85f));
                }

                // ================= RAIN =================

                if (!cloudEntering &&
                    !cloudLeaving &&
                    cloudAlpha >= 1.0f &&
                    cycleScore >= 61 &&
                    cycleScore <= 87)
                {
                    for (int i = 0; i < rainCount; i++)
                    {
                        Color rainColor = (summerPhase == 4)
                                              ? (Color){220, 235, 255, 180}
                                              : (Color){90, 170, 255, 150};

                        DrawLineEx(
                            (Vector2){rain[i].x, rain[i].y},
                            (Vector2){rain[i].x - 2, rain[i].y + 10},
                            1.5f,
                            rainColor);
                    }
                }
            }
            // ===== DRAW DINO =====
            // Crouch draw dimensions
            float crouchDrawW = 68.0f;
            float crouchDrawH = 46.0f;
            float crouchOffsetY = (float)dinoHeight - crouchDrawH; // vertically align to ground

            // Torch position relative to dino size
            int torchX = dinoX + dinoWidth - 10;
            int torchY = dinoY + (int)(dinoHeight * 0.30f);

            if (isCrouching)
            {
                DrawTexturePro(
                    dinoCrouchTexture,
                    (Rectangle){0, 0, (float)dinoCrouchTexture.width, (float)dinoCrouchTexture.height},
                    (Rectangle){(float)dinoX, (float)(dinoY + crouchOffsetY), crouchDrawW, crouchDrawH},
                    (Vector2){0, 0},
                    0.0f,
                    WHITE);
                // Recalculate torch for crouch
                torchX = dinoX + (int)crouchDrawW - 8;
                torchY = dinoY + (int)crouchOffsetY + (int)(crouchDrawH * 0.25f);
            }
            else if (isJumping)
            {
                DrawTexturePro(
                    dinoJump,
                    (Rectangle){0, 0, (float)dinoJump.width, (float)dinoJump.height},
                    (Rectangle){(float)dinoX, (float)dinoY, (float)dinoWidth, (float)dinoHeight},
                    (Vector2){0, 0},
                    0.0f,
                    WHITE);
            }
            else if (isMoving)
            {
                if (dinoRunFrame == 0)
                {
                    DrawTexturePro(
                        dinoRun1Texture,
                        (Rectangle){0, 0, (float)dinoRun1Texture.width, (float)dinoRun1Texture.height},
                        (Rectangle){(float)dinoX, (float)dinoY, (float)dinoWidth, (float)dinoHeight},
                        (Vector2){0, 0},
                        0.0f,
                        WHITE);
                }
                else
                {
                    DrawTexturePro(
                        dinoRun2Texture,
                        (Rectangle){0, 0, (float)dinoRun2Texture.width, (float)dinoRun2Texture.height},
                        (Rectangle){(float)dinoX, (float)dinoY, (float)dinoWidth, (float)dinoHeight},
                        (Vector2){0, 0},
                        0.0f,
                        WHITE);
                }
            }
            else
            {
                DrawTexturePro(
                    dinoIdleTexture,
                    (Rectangle){0, 0, (float)dinoIdleTexture.width, (float)dinoIdleTexture.height},
                    (Rectangle){(float)dinoX, (float)dinoY, (float)dinoWidth, (float)dinoHeight},
                    (Vector2){0, 0},
                    0.0f,
                    WHITE);
            }
            int torchOffsetY = 10; // Increase/decrease this value to move the torch
            if (glowAndStickPhase)
            {
                // torch stick
                float torchRotation = isCrouching ? 240.0f : 200.0f;

                DrawRectanglePro(
                    (Rectangle){(float)torchX, (float)(torchY + torchOffsetY), 3.0f, 15.0f},
                    (Vector2){1.5f, 13.0f},
                    torchRotation,
                    BROWN);

                // flame
                DrawCircle(
                    torchX + 1,
                    torchY + torchOffsetY - 2,
                    5,
                    ORANGE);

                DrawCircle(
                    torchX + 1,
                    torchY + torchOffsetY - 2,
                    3,
                    YELLOW);
            }

            if (glowAndStickPhase)
            {
                DrawCircle(
                    torchX + 1,
                    torchY + torchOffsetY - 2,
                    100,
                    Fade(YELLOW, 0.01f));

                DrawCircle(
                    torchX + 1,
                    torchY + torchOffsetY - 2,
                    70,
                    Fade(ORANGE, 0.02f));

                DrawCircle(
                    torchX + 1,
                    torchY + torchOffsetY - 2,
                    40,
                    Fade(YELLOW, 0.03f));
            }
            // ===== DRAW CACTUS 1 =====
            Texture2D cactus1Texture = GetCactusTextureForType(cactusType, selectedEnvironment == 2);
            if (glowAndStickPhase)
            {
                // Soft green glow (behind cactus)
                DrawCircle(
                    cactusX + cactusWidth / 2,
                    cactusY + cactusHeight / 2,
                    cactusWidth + 6,
                    Fade(GREEN, 0.05f));

                DrawCircle(
                    cactusX + cactusWidth / 2,
                    cactusY + cactusHeight / 2,
                    cactusWidth + 2,
                    Fade(LIME, 0.08f));
            }

            DrawTexturePro(
                cactus1Texture,
                (Rectangle){0, 0, (float)cactus1Texture.width, (float)cactus1Texture.height},
                (Rectangle){(float)cactusX, (float)cactusY, (float)cactusWidth, (float)cactusHeight},
                (Vector2){0, 0},
                0,
                glowAndStickPhase ? (Color){180, 255, 180, 255} : WHITE);

            if (secondCactusActive)
            {
                Texture2D cactus2TextureToDraw = GetCactusTextureForType(cactus2Type, selectedEnvironment == 2);
                if (glowAndStickPhase)
                {
                    DrawCircle(
                        cactus2X + cactus2Width / 2,
                        cactus2Y + cactus2Height / 2,
                        cactus2Width + 6,
                        Fade(GREEN, 0.05f));

                    DrawCircle(
                        cactus2X + cactus2Width / 2,
                        cactus2Y + cactus2Height / 2,
                        cactus2Width + 2,
                        Fade(LIME, 0.08f));
                }
                DrawTexturePro(
                    cactus2TextureToDraw,
                    (Rectangle){0, 0, (float)cactus2TextureToDraw.width, (float)cactus2TextureToDraw.height},
                    (Rectangle){(float)cactus2X, (float)cactus2Y, (float)cactus2Width, (float)cactus2Height},
                    (Vector2){0, 0},
                    0.0f,
                    glowAndStickPhase ? (Color){180, 255, 180, 255} : WHITE);
            }

            // ===== DRAW BIRD (Using textures with scaling) =====
            if (birdActive)
            {
                auto DrawBirdSprite = [&](float bx, float by) {
                    if (glowAndStickPhase)
                    {
                        DrawCircle(bx + 20, by + 10, 18, Fade(WHITE, 0.12f));
                    }
                    if (birdAnimationType == 0)
                    {
                        DrawTexturePro(
                            birdUpTexture,
                            (Rectangle){0, 0, (float)birdUpTexture.width, (float)birdUpTexture.height},
                            (Rectangle){bx, by, 40.0f, 20.0f},
                            (Vector2){0, 0},
                            0.0f,
                            glowAndStickPhase ? (Color){190, 210, 255, 255} : WHITE);
                    }
                    else if (birdAnimationType == 1)
                    {
                        DrawTexturePro(
                            birdLevel2Texture,
                            (Rectangle){0, 0, (float)birdLevel2Texture.width, (float)birdLevel2Texture.height},
                            (Rectangle){bx, by, 40.0f, 20.0f},
                            (Vector2){0, 0},
                            0.0f,
                            glowAndStickPhase ? (Color){190, 210, 255, 255} : WHITE);
                    }
                    else
                    {
                        DrawTexturePro(
                            birdDown2Texture,
                            (Rectangle){0, 0, (float)birdDown2Texture.width, (float)birdDown2Texture.height},
                            (Rectangle){bx, by, 40.0f, 20.0f},
                            (Vector2){0, 0},
                            0.0f,
                            glowAndStickPhase ? (Color){190, 210, 255, 255} : WHITE);
                    }
                };

                DrawBirdSprite((float)birdX, (float)birdY);
                if (isDoubleBird)
                {
                    // Draw second bird underneath the first
                    DrawBirdSprite((float)birdX, (float)birdY + birdHeight + 90.0f);
                }
            }

            // Draw UI
            Color textColor = DARKGRAY;

            if (selectedEnvironment == 1)
            {
                // Summer night: white text
                if (summerPhase == 1)
                    textColor = WHITE;
            }
            else if (selectedEnvironment == 2)
            {
                // Winter night: white text
                if (summerPhase == 1)
                    textColor = WHITE;
            }
            DrawText("Press SPACE to JUMP", 10, 10, 20, textColor);
            DrawText("Use LEFT RIGHT arrows to MOVE", 10, 40, 20, textColor);
            DrawText(TextFormat("Score: %d", score), 650, 20, 20, textColor);
            DrawText(TextFormat("High Score: %d", highscore), 600, 50, 20, textColor);

            // Game over screen
            if (gameOver)
            {
                DrawText("GAME OVER", 280, 150, 40, RED);
                DrawText("Press R to restart", 285, 195, 25, DARKGRAY);
                DrawText(TextFormat("High Score: %d", highscore), 320, 240, 25, BLUE);
            }
        } // Close gameStarted else block

        if (showTutorial)
        {
            // Semi-transparent overlay to dim the game
            DrawRectangle(0, 0, screenWidth, screenHeight, Fade(BLACK, 0.4f));

            // ===== Draw tutorial image centered =====
            float tutScale = fminf((float)screenWidth / tutorial.width, (float)screenHeight / tutorial.height);
            float tutW = tutorial.width * tutScale;
            float tutH = tutorial.height * tutScale;
            float tutX = (screenWidth - tutW) / 2.0f;
            float tutY = (screenHeight - tutH) / 2.0f;

            DrawTexturePro(
                tutorial,
                (Rectangle){0, 0, (float)tutorial.width, (float)tutorial.height},
                (Rectangle){tutX, tutY, tutW, tutH},
                (Vector2){0, 0},
                0,
                WHITE
            );

            // ===== "Press Enter to Start" text =====
            static float tutPulseTimer = 0.0f;
            tutPulseTimer += GetFrameTime() * 3.0f;
            float tutPulse = (sinf(tutPulseTimer) + 1.0f) / 2.0f; // 0.0 to 1.0

            Color themeColor = (selectedEnvironment == 1)
                ? (Color){255, 160, 30, 255}   // warm orange for summer
                : (Color){100, 180, 255, 255};  // icy blue for winter

            const char* enterText = "Press ENTER to Start";
            int fontSize = 20;
            int textW = MeasureText(enterText, fontSize);
            int textX = 400 - textW / 2;
            int textY = 390;

            // Shadow
            DrawText(enterText, textX + 1, textY + 1, fontSize, (Color){0, 0, 0, 150});
            // Pulsing glow
            DrawText(enterText, textX, textY, fontSize, Fade(themeColor, 0.55f + 0.45f * tutPulse));
        }

        EndMode2D();
        EndDrawing();
    } // End while loop

    // Unload bird, cactus, and dino textures
    UnloadTexture(birdUpTexture);
    UnloadTexture(birdLevel2Texture);
    UnloadTexture(birdDown2Texture);
    UnloadTexture(cactusTexture);
    UnloadTexture(cactusShortTexture);
    UnloadTexture(cactusTallTexture);
    UnloadTexture(cactusVeryTallTexture);
    UnloadTexture(dinoIdleTexture);
    UnloadTexture(dinoRun1Texture);
    UnloadTexture(dinoRun2Texture);
    UnloadTexture(desertBG);
    UnloadTexture(snowBG);
    UnloadTexture(cactusSnowTexture);
    UnloadTexture(cactusShortSnowTexture);
    UnloadTexture(cactusTallSnowTexture);
    UnloadTexture(cactusVeryTallSnowTexture);
    UnloadTexture(cactusFrostedTexture);
    UnloadTexture(dinoJump);
    UnloadTexture(dinoCrouchTexture);
    UnloadTexture(menu);
    UnloadTexture(tutorial);

    UnloadSound(jumpSfx);
    UnloadSound(landingSfx);
    UnloadSound(gameOverSfx);
    UnloadSound(thunderSfx);
    UnloadSound(buttonSfx);
    UnloadMusicStream(gameMenuMusic);
    UnloadMusicStream(gameBgMusic);
    UnloadMusicStream(rainMusic);
    UnloadMusicStream(snowMusic);
    CloseAudioDevice();

    CloseWindow();
    return 0;
}
